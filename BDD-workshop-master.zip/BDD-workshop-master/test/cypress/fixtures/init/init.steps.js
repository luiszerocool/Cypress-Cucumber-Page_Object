import { Given, When, Then  } from 'cypress-cucumber-preprocessor/steps';


Given(/^an add function$/, function () {
  return true;
});

When(/^I add two numbers$/, function () {
  return true;
});

Then(/^result is correct$/, function () {
  return true;
});

